const displayMessage = require('./0-console');

displayMessage('Hello NodeJS!');
